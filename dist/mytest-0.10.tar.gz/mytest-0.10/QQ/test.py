import os

print os.environ.keys()